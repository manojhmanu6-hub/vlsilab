// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module uart_tb;

reg clk;
reg rst;
reg tx_start;
reg [7:0] tx_data;

wire tx;
wire tx_busy;
wire [7:0] rx_data;
wire rx_done;

// Instantiate modules
uart_tx tx_unit (
    .clk(clk),
    .rst(rst),
    .tx_start(tx_start),
    .tx_data(tx_data),
    .tx(tx),
    .tx_busy(tx_busy)
);

uart_rx rx_unit (
    .clk(clk),
    .rst(rst),
    .rx(tx),
    .rx_data(rx_data),
    .rx_done(rx_done)
);

// Waveform
initial begin
    $dumpfile("dump.vcd");
    $dumpvars(1, uart_tb);
end

// Clock
initial begin
    clk = 0;
    forever #10 clk = ~clk;
end

// Test
initial begin
    rst = 1;
    tx_start = 0;
    tx_data = 8'hA5;

    #50;
    rst = 0;

    #50;

    tx_start = 1;
    #100;
    tx_start = 0;

    wait (rx_done);

    #100;
    $finish;
end

endmodule