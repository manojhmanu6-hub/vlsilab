// Code your design here
module uart_tx (
    input wire clk,
    input wire rst,
    input wire tx_start,
    input wire [7:0] tx_data,
    output reg tx,
    output reg tx_busy
);

parameter CLKS_PER_BIT = 20;  // 🔥 fast simulation

reg [15:0] clk_count;
reg [3:0] bit_index;
reg [7:0] data_reg;
reg [1:0] state;

localparam IDLE=0, START=1, DATA=2, STOP=3;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        state <= IDLE;
        tx <= 1;
        tx_busy <= 0;
        clk_count <= 0;
        bit_index <= 0;
    end else begin
        case(state)

        IDLE: begin
            tx <= 1;
            tx_busy <= 0;
            if (tx_start) begin
                tx_busy <= 1;
                data_reg <= tx_data;
                state <= START;
                clk_count <= 0;
            end
        end

        START: begin
            tx <= 0;
            if (clk_count < CLKS_PER_BIT-1)
                clk_count <= clk_count + 1;
            else begin
                clk_count <= 0;
                bit_index <= 0;
                state <= DATA;
            end
        end

        DATA: begin
            tx <= data_reg[bit_index];
            if (clk_count < CLKS_PER_BIT-1)
                clk_count <= clk_count + 1;
            else begin
                clk_count <= 0;
                bit_index <= bit_index + 1;
                if (bit_index == 8)
                    state <= STOP;
            end
        end

        STOP: begin
            tx <= 1;
            if (clk_count < CLKS_PER_BIT-1)
                clk_count <= clk_count + 1;
            else begin
                state <= IDLE;
            end
        end

        endcase
    end
end

endmodule

module uart_rx (
    input wire clk,
    input wire rst,
    input wire rx,
    output reg [7:0] rx_data,
    output reg rx_done
);

parameter CLKS_PER_BIT = 20;  // 🔥 fast simulation

reg [15:0] clk_count;
reg [3:0] bit_index;
reg [7:0] data_reg;
reg [1:0] state;

localparam IDLE=0, START=1, DATA=2, STOP=3;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        state <= IDLE;
        clk_count <= 0;
        bit_index <= 0;
        rx_done <= 0;
    end else begin
        rx_done <= 0;

        case(state)

        IDLE: begin
            if (rx == 0) begin
                state <= START;
                clk_count <= CLKS_PER_BIT/2; // mid-bit sampling
            end
        end

        START: begin
            if (clk_count < CLKS_PER_BIT-1)
                clk_count <= clk_count + 1;
            else begin
                clk_count <= 0;
                bit_index <= 0;
                state <= DATA;
            end
        end

        DATA: begin
            if (clk_count < CLKS_PER_BIT-1)
                clk_count <= clk_count + 1;
            else begin
                clk_count <= 0;
                data_reg[bit_index] <= rx;
                bit_index <= bit_index + 1;

                if (bit_index == 7)
                    state <= STOP;
            end
        end

        STOP: begin
            if (clk_count < CLKS_PER_BIT-1)
                clk_count <= clk_count + 1;
            else begin
                rx_data <= data_reg;
                rx_done <= 1;
                state <= IDLE;
            end
        end

        endcase
    end
end

endmodule