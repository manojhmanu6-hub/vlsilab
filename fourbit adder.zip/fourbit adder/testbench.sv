// Code your testbench here
// or browse Examples
module tb_four_bit_adder();
  reg [3:0]a,b;
  reg cin;
  wire [3:0]sum;
  wire cout;
  four_bit_adder dut(a,b,cin,sum,cout);
  initial begin
    $dumpfile("adder.vcd");
    $dumpvars(0, tb_four_bit_adder);
    #10 a=4'b0001;b=4'b0010;cin=0;
    #10 a=4'b0100;b=4'b0011;cin=1;
    #10 a=4'b1111;b=4'b0001;cin=0;
    $finish;
  end
endmodule
