// Code your testbench here
// or browse Examples
module tb_alu();
  reg [7:0] A,B;
  reg [2:0] sel;
  wire [7:0] result;
  wire carryout,zero;
  
  alu uut(
    .A(A),
    .B(B),
    .sel(sel),
    .result(result),
    .carryout(carryout),
    .zero(zero)
  );
  
  initial begin
    $dumpfile("alu.vcd");
    $dumpvars(0,tb_alu);
    A = 8'd15;B = 8'd10;sel=3'b000; #10;
    A = 8'd10;B = 8'd5;sel=3'b001; #10;
    A = 8'b11001100;B = 8'b10101010;sel = 3'b010; #10;
    A = 8'b11001100;B = 8'b10101010;sel = 3'b011; #10;
    A = 8'b11001100;B = 8'b10101010;sel = 3'b100; #10;
    $finish;
  end
endmodule
  
  