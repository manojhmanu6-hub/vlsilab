module alu(
  input [7:0] A,
  input [7:0] B,
  input [2:0] sel,
  output reg [7:0] result,
  output reg carryout,
  output zero
);
  always @(*) begin
    case(sel)
      3'b000:{carryout,result} = A+B;
      3'b001:{carryout,result} = A-B;
      3'b010:{carryout,result} = {1'b0, A&B};
      3'b011:{carryout,result} = {1'b0, A|B};
      3'b100:{carryout,result} = {1'b0, A^B};
    endcase
  end
  assign zero = (result == 8'b0) ? 1'b1 : 1'b0;
endmodule