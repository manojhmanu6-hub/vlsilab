module traffic_light_controller (
    input clk,          
    input reset,        
    output reg [1:0] NS_light, // 00=Red, 01=Yellow, 10=Green
    output reg [1:0] EW_light
);

// State definitions
parameter NS_GREEN_EW_RED   = 2'b00,
          NS_YELLOW_EW_RED  = 2'b01,
          NS_RED_EW_GREEN   = 2'b10,
          NS_RED_EW_YELLOW  = 2'b11;

reg [1:0] state, next_state;

// ================= STATE REGISTER =================
always @(posedge clk or posedge reset) begin
    if (reset)
        state <= NS_GREEN_EW_RED;
    else
        state <= next_state;
end

// ================= NEXT STATE LOGIC =================
always @(*) begin
    case(state)
        NS_GREEN_EW_RED:   next_state = NS_YELLOW_EW_RED;
        NS_YELLOW_EW_RED:  next_state = NS_RED_EW_GREEN;
        NS_RED_EW_GREEN:   next_state = NS_RED_EW_YELLOW;
        NS_RED_EW_YELLOW:  next_state = NS_GREEN_EW_RED;
        default:           next_state = NS_GREEN_EW_RED;
    endcase
end

// ================= OUTPUT LOGIC =================
always @(*) begin
    case(state)
        NS_GREEN_EW_RED: begin
            NS_light = 2'b10; // Green
            EW_light = 2'b00; // Red
        end

        NS_YELLOW_EW_RED: begin
            NS_light = 2'b01; // Yellow
            EW_light = 2'b00; // Red
        end

        NS_RED_EW_GREEN: begin
            NS_light = 2'b00; // Red
            EW_light = 2'b10; // Green
        end

        NS_RED_EW_YELLOW: begin
            NS_light = 2'b00; // Red
            EW_light = 2'b01; // Yellow
        end

        default: begin
            NS_light = 2'b00;
            EW_light = 2'b00;
        end
    endcase
end

endmodule