module tb_traffic_light;

reg clk;
reg reset;
wire [1:0] NS_light;
wire [1:0] EW_light;

// Instantiate DUT
traffic_light_controller uut (
    .clk(clk),
    .reset(reset),
    .NS_light(NS_light),
    .EW_light(EW_light)
);

// Clock generation (10ns period)
always #5 clk = ~clk;

// Test sequence + VCD generation
initial begin
    $dumpfile("dump.vcd");        // For waveform
    $dumpvars(0, tb_traffic_light);

    clk = 0;
    reset = 1;

    #10 reset = 0;   // Release reset

    #100 $finish;    // End simulation
end

// Monitor values
initial begin
    $monitor("Time=%0t | NS=%b | EW=%b", $time, NS_light, EW_light);
end

endmodule